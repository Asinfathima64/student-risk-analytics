# AI-Powered Student Performance Prediction and Academic Risk Analysis

A complete local web application: **React (Vite) dashboard** + **Python Flask API** + **scikit-learn models**.

> **All student records in this project are SYNTHETIC (computer-generated) demonstration data. They are not real students.**
> Model scores on synthetic data do not prove the model would work on real students.

## What it does

| Page | What you can do |
|------|-----------------|
| Dashboard | See totals, averages, students below the pass mark, three charts, and the model evaluation (accuracy, precision, recall, F1, confusion matrix) |
| Predict | Enter attendance, study hours, previous marks, assignment and participation scores and get a risk estimate with a supportive explanation |
| Dataset | Download the sample CSV, upload your own CSV (validated and cleaned), restore the sample, retrain the model |

**Prediction target:** a student is **"At Risk"** when **final marks are below 50**.
**Inputs (5):** attendance %, study hours/day, previous marks, assignment score, participation score.
`final_marks` is **never** a model input (that would be target leakage).

## Folder structure

```
student-risk-project/
├── README.md
├── backend/
│   ├── app.py                    Flask API (all endpoints)
│   ├── config.py                 threshold, seed, feature names, valid ranges, paths
│   ├── requirements.txt
│   ├── ml/
│   │   ├── data_generator.py     creates the synthetic CSV (seeded, reproducible)
│   │   ├── data_loader.py        reads + validates CSVs (missing, invalid, duplicate, out-of-range)
│   │   ├── preprocessing.py      label creation + imputer/scaler
│   │   ├── train.py              split, cross-validate, compare 2 models, save pipeline
│   │   ├── evaluate.py           accuracy / precision / recall / F1 / confusion matrix
│   │   ├── predict.py            hash-verified model loading + single prediction + explanation
│   │   └── dataset_service.py    dashboard numbers, upload/reset/retrain logic
│   ├── data/students_synthetic.csv    600 synthetic students
│   ├── models/                   saved pipeline + metrics.json (created by training)
│   └── tests/                    32 automated tests (pytest)
├── frontend/
│   ├── package.json, vite.config.js, .env
│   ├── src/api/                  client.js (all HTTP calls), useApi.js
│   ├── src/pages/                Dashboard, Predict, DatasetPage
│   ├── src/components/           Layout, StatCard, Charts, ModelEvaluation, PredictionResult, Feedback
│   ├── src/styles/app.css
│   └── tests/                    API-client integration tests
└── docs/                         report, slides, viva questions, testing, architecture
```

## Requirements

* **Windows 10/11**, PowerShell
* **Python 3.10 or newer** (download from python.org; tick **"Add python.exe to PATH"** during install)
* **Node.js 18 or newer, LTS** (download from nodejs.org)

Check them:

```powershell
python --version
node --version
npm --version
```

## Setup and run (two PowerShell windows)

Open PowerShell and move into the project folder, e.g. `cd C:\Users\YOU\Desktop\student-risk-project`.

### Window 1 - Backend (Python)

```powershell
cd backend
python -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

* `Set-ExecutionPolicy ... -Scope Process` only affects this window and lets the venv activate.
* The first start creates the dataset (if missing) and trains the model (a few seconds). The CSV and model are
  already included, so it usually starts immediately.
* Success looks like: `Running on http://127.0.0.1:5000`. **Leave this window open.**
* Quick check in a browser: <http://127.0.0.1:5000/api/health> should show `"status":"ok"`.

### Window 2 - Frontend (React)

```powershell
cd frontend
npm install
npm run dev
```

Open **<http://localhost:5173>** in your browser. Leave both windows open while presenting.

### Optional: train the model manually

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
python -m ml.data_generator     # re-create the synthetic CSV
python -m ml.train              # train, compare, and save the model; prints the results
```

### Run the automated tests

Backend (no server needs to be running):

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
python -m pytest -q
```

Frontend API-client tests (the backend **must be running** in the other window):

```powershell
cd frontend
npm test
```

## API endpoints

Base URL: `http://127.0.0.1:5000/api` (change it in `frontend/.env` via `VITE_API_URL`).

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/health` | Is the server up and the model loaded? |
| GET | `/meta` | Input field names, labels, valid ranges, threshold |
| GET | `/dataset/summary` | All dashboard numbers and chart data |
| GET | `/dataset/sample` | Download the sample CSV |
| POST | `/dataset/upload` | Upload a CSV (form field `file`), validate, retrain |
| POST | `/dataset/reset` | Restore the synthetic sample and retrain |
| GET | `/model/metrics` | Saved evaluation results for both models |
| POST | `/model/retrain` | Retrain on the active dataset |
| POST | `/predict` | JSON with the 5 inputs -> risk category, probability, explanation |

**CORS:** the backend accepts requests from `http://localhost:5173` and `http://127.0.0.1:5173`.
To allow another address, set an environment variable before starting the backend, for example:
`$env:FRONTEND_ORIGINS="http://localhost:3000"; python app.py`

## CSV format

Required columns: `attendance_pct`, `study_hours_per_day`, `previous_marks`, `assignment_score`,
`participation_score`, `final_marks`. Optional: `student_id`. Valid ranges are 0-100 (study hours 0-16).
Rows with missing, non-numeric or out-of-range values and exact duplicates are removed and reported with row numbers.
At least 100 clean rows are needed, with at least 10 students on each side of the threshold.
If an upload fails, your previous dataset and model stay untouched.

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `python` is not recognized | Reinstall Python and tick "Add python.exe to PATH", or try `py -m venv .venv` and `py app.py` |
| `Activate.ps1 cannot be loaded because running scripts is disabled` | Run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that window, then activate again |
| `pip install` fails building scikit-learn/pandas | Use Python 3.10-3.13 (64-bit). Run `python -m pip install --upgrade pip` and retry |
| Dashboard shows "The backend is not responding" | Window 1 is not running, or crashed. Restart `python app.py` and click "Check again" |
| Browser console shows a CORS error | Open the app at exactly `http://localhost:5173` (or `127.0.0.1:5173`). See the CORS note above |
| `Port 5000 is already in use` | Close the other program, or run `$env:PORT=5001; python app.py` and set `VITE_API_URL=http://127.0.0.1:5001/api` in `frontend/.env`, then restart `npm run dev` |
| `Port 5173 is already in use` | Close the other Vite window. The app needs 5173 because CORS allows it |
| `npm install` errors / very slow | Check internet; delete the `node_modules` folder and `package-lock.json`, run `npm install` again |
| "The model file does not match its recorded hash" | The model file changed. Run `python -m ml.train` (or press "Retrain model" on the Dataset page) |
| Changed `.env` but nothing happens | Stop `npm run dev` (Ctrl+C) and start it again; Vite reads `.env` only at start |
| Upload says "Only N valid rows remain" | Your file has too many bad rows or too few rows. Read the listed row numbers and fix them |

## Honest limitations

* The data is synthetic; its patterns are assumptions I wrote into the generator, so the model mostly rediscovers those assumptions.
* The risk label (final marks < 50) is a simple threshold; real support decisions need more context.
* Only five inputs are used; real learning is affected by many other things.
* Predicted probabilities are estimates and may be poorly calibrated.
* The app has no login, no database and no multi-user support. It is a local demo, not production software.
* Fairness across student groups has not been evaluated (the data has no demographic fields).

See `docs/` for the full report, slides, viva questions and testing notes.
