"""
Flask REST API.

Run from the backend folder:   python app.py
API base URL (default):        http://127.0.0.1:5000/api
"""
import os

from flask import Flask, jsonify, request, send_file
from flask_cors import CORS

from config import (
    CLASS_LABELS, FEATURE_INFO, MAX_UPLOAD_MB, RISK_THRESHOLD, SAMPLE_DATASET_PATH, FEATURES,
)
from ml import dataset_service
from ml.data_generator import write_sample_dataset
from ml.data_loader import DatasetValidationError
from ml.predict import InputValidationError, ModelNotReadyError, predict_one, read_metrics

# Which web pages may call this API. Edit via the FRONTEND_ORIGINS environment variable.
DEFAULT_ORIGINS = "http://localhost:5173,http://127.0.0.1:5173"


def create_app(bootstrap: bool = True) -> Flask:
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024
    origins = [o.strip() for o in os.environ.get("FRONTEND_ORIGINS", DEFAULT_ORIGINS).split(",") if o.strip()]
    CORS(app, resources={r"/api/*": {"origins": origins}})

    if bootstrap:
        dataset_service.ensure_ready()

    # ---------------------------------------------------------------- health
    @app.get("/api/health")
    def health():
        try:
            metrics = read_metrics()
            model_ready, selected = True, metrics["selected_model"]
        except ModelNotReadyError:
            model_ready, selected = False, None
        return jsonify({"status": "ok", "model_ready": model_ready, "selected_model": selected})

    # ------------------------------------------------------------------ meta
    @app.get("/api/meta")
    def meta():
        return jsonify({
            "features": [{"name": f, **FEATURE_INFO[f]} for f in FEATURES],
            "risk_threshold": RISK_THRESHOLD,
            "class_labels": CLASS_LABELS,
            "max_upload_mb": MAX_UPLOAD_MB,
        })

    # --------------------------------------------------------------- dataset
    @app.get("/api/dataset/summary")
    def summary():
        return jsonify(dataset_service.dataset_summary())

    @app.get("/api/dataset/sample")
    def download_sample():
        if not SAMPLE_DATASET_PATH.exists():
            write_sample_dataset()
        return send_file(SAMPLE_DATASET_PATH, mimetype="text/csv", as_attachment=True,
                         download_name="students_synthetic_sample.csv")

    @app.post("/api/dataset/upload")
    def upload():
        file = request.files.get("file")
        if file is None or not file.filename:
            raise DatasetValidationError("No file received. Choose a .csv file and try again.")
        result = dataset_service.ingest_upload(file)
        return jsonify({"message": "Dataset accepted and model retrained.", **result})

    @app.post("/api/dataset/reset")
    def reset():
        dataset_service.reset_to_sample()
        return jsonify({"message": "Sample synthetic dataset restored and model retrained."})

    # ----------------------------------------------------------------- model
    @app.get("/api/model/metrics")
    def metrics():
        return jsonify(read_metrics())

    @app.post("/api/model/retrain")
    def retrain():
        result = dataset_service.retrain_active()
        return jsonify({"message": "Model retrained.", "selected_model": result["selected_model"]})

    @app.post("/api/predict")
    def predict():
        payload = request.get_json(silent=True)
        if payload is None:
            raise InputValidationError({"_form": "Send the input values as JSON."})
        return jsonify(predict_one(payload))

    # --------------------------------------------------------------- errors
    @app.errorhandler(DatasetValidationError)
    def bad_dataset(err):
        return jsonify({"error": err.message, "details": err.details}), 400

    @app.errorhandler(InputValidationError)
    def bad_input(err):
        return jsonify({"error": "Please correct the highlighted inputs.", "fields": err.errors}), 400

    @app.errorhandler(ModelNotReadyError)
    def no_model(err):
        return jsonify({"error": str(err)}), 503

    @app.errorhandler(FileNotFoundError)
    def no_file(err):
        return jsonify({"error": str(err)}), 503

    @app.errorhandler(413)
    def too_big(_err):
        return jsonify({"error": f"File is too large. The limit is {MAX_UPLOAD_MB} MB."}), 413

    @app.errorhandler(404)
    def not_found(_err):
        return jsonify({"error": "Endpoint not found."}), 404

    @app.errorhandler(405)
    def wrong_method(_err):
        return jsonify({"error": "Method not allowed for this endpoint."}), 405

    @app.errorhandler(Exception)
    def unexpected(err):
        app.logger.exception("Unexpected error")
        return jsonify({"error": "Something went wrong on the server. Check the backend terminal for details."}), 500

    return app


if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
