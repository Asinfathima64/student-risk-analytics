"""
Central configuration for the Student Risk project.

Everything that other modules need to agree on (feature names, valid ranges,
the risk threshold, file paths, the random seed) lives here, so there is one
single place to change it.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"

# ---- Files -----------------------------------------------------------------
SAMPLE_DATASET_PATH = DATA_DIR / "students_synthetic.csv"   # generated, never overwritten by uploads
ACTIVE_DATASET_PATH = DATA_DIR / "active_dataset.csv"       # the dataset the app currently uses
ACTIVE_DATASET_META_PATH = DATA_DIR / "active_dataset_meta.json"
MODEL_PATH = MODEL_DIR / "risk_pipeline.joblib"
METRICS_PATH = MODEL_DIR / "metrics.json"

# ---- Reproducibility -------------------------------------------------------
RANDOM_SEED = 42
TEST_SIZE = 0.20
CV_FOLDS = 5

# ---- Problem definition ----------------------------------------------------
# A student is labelled "At Risk" (class 1) when FINAL marks are below this value.
RISK_THRESHOLD = 50.0
CLASS_LABELS = {0: "On Track", 1: "At Risk"}

# ---- Columns ---------------------------------------------------------------
# Input features used by the model. NOTE: final_marks is deliberately NOT here,
# because the label is derived from final_marks (that would be target leakage).
FEATURES = [
    "attendance_pct",
    "study_hours_per_day",
    "previous_marks",
    "assignment_score",
    "participation_score",
]
TARGET_SOURCE = "final_marks"
OPTIONAL_COLUMNS = ["student_id"]

# Human-friendly names and valid ranges (min, max) - used for validation AND for the form.
FEATURE_INFO = {
    "attendance_pct":      {"label": "Attendance (%)",            "min": 0, "max": 100, "step": 1,   "default": 75},
    "study_hours_per_day": {"label": "Study hours per day",       "min": 0, "max": 16,  "step": 0.5, "default": 3},
    "previous_marks":      {"label": "Previous marks (0-100)",    "min": 0, "max": 100, "step": 1,   "default": 60},
    "assignment_score":    {"label": "Assignment score (0-100)",  "min": 0, "max": 100, "step": 1,   "default": 65},
    "participation_score": {"label": "Participation score (0-100)", "min": 0, "max": 100, "step": 1, "default": 60},
}
RANGES = {name: (info["min"], info["max"]) for name, info in FEATURE_INFO.items()}
RANGES[TARGET_SOURCE] = (0, 100)

# ---- Upload limits ---------------------------------------------------------
MAX_UPLOAD_MB = 5
MIN_ROWS_FOR_TRAINING = 100       # fewer clean rows than this -> upload rejected
MIN_CLASS_COUNT = 10              # each class needs at least this many rows

# ---- Dataset generation ----------------------------------------------------
SYNTHETIC_ROWS = 600
