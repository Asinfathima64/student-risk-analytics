"""
Synthetic dataset generator.

IMPORTANT: this creates SYNTHETIC DEMONSTRATION DATA. These are NOT real students.
The relationships (e.g. "more attendance -> higher marks") are assumptions written
by the project author, so a model trained on this data learns those assumptions,
not real-world truth.

How the data is made (fully reproducible with the same seed):
1. Each student gets a hidden "ability" value drawn from a normal distribution.
2. Each feature is a noisy function of ability and of other simple factors.
3. final_marks is a weighted mix of the features plus random noise, clipped to 0-100.
"""
import numpy as np
import pandas as pd

from config import RANDOM_SEED, SYNTHETIC_ROWS, SAMPLE_DATASET_PATH, ACTIVE_DATASET_PATH


def generate_dataset(n_rows: int = SYNTHETIC_ROWS, seed: int = RANDOM_SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    ability = rng.normal(0, 1, n_rows)                       # hidden, not saved
    motivation = rng.normal(0, 1, n_rows)                    # hidden, not saved

    attendance = 78 + 9 * motivation + 3 * ability + rng.normal(0, 6, n_rows)
    study_hours = 3.0 + 1.1 * motivation + 0.4 * ability + rng.normal(0, 0.8, n_rows)
    previous = 62 + 13 * ability + 2 * motivation + rng.normal(0, 6, n_rows)
    assignment = 64 + 10 * ability + 5 * motivation + rng.normal(0, 8, n_rows)
    participation = 60 + 8 * motivation + 4 * ability + rng.normal(0, 12, n_rows)

    attendance = np.clip(attendance, 30, 100)
    study_hours = np.clip(study_hours, 0, 10)
    previous = np.clip(previous, 15, 100)
    assignment = np.clip(assignment, 10, 100)
    participation = np.clip(participation, 5, 100)

    final = (
        0.30 * previous
        + 0.25 * assignment
        + 0.20 * attendance
        + 2.2 * study_hours
        + 0.10 * participation
        + rng.normal(0, 7, n_rows)
        - 2.0
    )
    final = np.clip(final, 0, 100)

    df = pd.DataFrame(
        {
            "student_id": [f"S{idx:04d}" for idx in range(1, n_rows + 1)],
            "attendance_pct": attendance.round(1),
            "study_hours_per_day": study_hours.round(1),
            "previous_marks": previous.round(1),
            "assignment_score": assignment.round(1),
            "participation_score": participation.round(1),
            "final_marks": final.round(1),
        }
    )
    return df


def write_sample_dataset(seed: int = RANDOM_SEED) -> pd.DataFrame:
    """Create data/students_synthetic.csv (and make it the active dataset)."""
    SAMPLE_DATASET_PATH.parent.mkdir(parents=True, exist_ok=True)
    df = generate_dataset(seed=seed)
    df.to_csv(SAMPLE_DATASET_PATH, index=False)
    df.to_csv(ACTIVE_DATASET_PATH, index=False)
    return df


if __name__ == "__main__":
    data = write_sample_dataset()
    print(f"Wrote {len(data)} SYNTHETIC rows to {SAMPLE_DATASET_PATH}")
    print(data.describe().round(1))
