"""
Dataset loading and validation.

Policy (documented so the behaviour is predictable):
  * Missing REQUIRED COLUMNS            -> whole file rejected.
  * Rows with missing / non-numeric / out-of-range values -> those rows are removed
    and reported (with row numbers). We do not silently "fix" marks values.
  * Exact duplicate rows                -> removed and counted.
  * Too few clean rows, or a class with too few examples -> file rejected.
"""
from dataclasses import dataclass, field
from typing import List

import pandas as pd

from config import (
    FEATURES, TARGET_SOURCE, OPTIONAL_COLUMNS, RANGES, RISK_THRESHOLD,
    MIN_ROWS_FOR_TRAINING, MIN_CLASS_COUNT, ACTIVE_DATASET_PATH,
)

REQUIRED_COLUMNS = FEATURES + [TARGET_SOURCE]
MAX_EXAMPLES_IN_MESSAGE = 5


class DatasetValidationError(ValueError):
    """Raised when a dataset cannot be used. The message is safe to show to users."""

    def __init__(self, message: str, details: List[str] | None = None):
        super().__init__(message)
        self.message = message
        self.details = details or []


@dataclass
class ValidationReport:
    rows_received: int = 0
    rows_kept: int = 0
    duplicates_removed: int = 0
    missing_value_rows: int = 0
    non_numeric_rows: int = 0
    out_of_range_rows: int = 0
    warnings: List[str] = field(default_factory=list)

    def to_dict(self):
        return self.__dict__.copy()


def _row_numbers(index, offset: int = 2) -> str:
    """Convert DataFrame index labels to spreadsheet-style row numbers (header = row 1)."""
    nums = [str(int(i) + offset) for i in list(index)[:MAX_EXAMPLES_IN_MESSAGE]]
    more = "" if len(index) <= MAX_EXAMPLES_IN_MESSAGE else f" (and {len(index) - MAX_EXAMPLES_IN_MESSAGE} more)"
    return ", ".join(nums) + more


def validate_dataframe(raw: pd.DataFrame):
    """Return (clean_df, ValidationReport). Raise DatasetValidationError if unusable."""
    report = ValidationReport(rows_received=len(raw))

    if raw.empty:
        raise DatasetValidationError("The file has no data rows.")

    df = raw.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]

    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        raise DatasetValidationError(
            f"Missing required column(s): {', '.join(missing_cols)}.",
            [f"Required columns: {', '.join(REQUIRED_COLUMNS)}. Optional: {', '.join(OPTIONAL_COLUMNS)}."],
        )

    keep_cols = [c for c in OPTIONAL_COLUMNS if c in df.columns] + REQUIRED_COLUMNS
    df = df[keep_cols]

    # --- 1. Duplicates (exact copies of a whole row) -----------------------------
    before = len(df)
    df = df.drop_duplicates()
    report.duplicates_removed = before - len(df)
    if "student_id" in df.columns:
        dup_ids = df["student_id"].notna() & df["student_id"].duplicated(keep="first")
        if dup_ids.any():
            report.warnings.append(
                f"{int(dup_ids.sum())} row(s) share a student_id with an earlier row but have different values. "
                f"They were kept - please check them (rows {_row_numbers(df.index[dup_ids])})."
            )

    # --- 2. Non-numeric values ---------------------------------------------------
    bad_mask = pd.Series(False, index=df.index)
    for col in REQUIRED_COLUMNS:
        original_missing = df[col].isna() | (df[col].astype(str).str.strip() == "")
        converted = pd.to_numeric(df[col], errors="coerce")
        non_numeric = converted.isna() & ~original_missing
        if non_numeric.any():
            report.warnings.append(
                f"Column '{col}': non-numeric value(s) in row(s) {_row_numbers(df.index[non_numeric])} - rows removed."
            )
        report.non_numeric_rows += int(non_numeric.sum())
        bad_mask |= non_numeric
        df[col] = converted

    # --- 3. Missing values -------------------------------------------------------
    for col in REQUIRED_COLUMNS:
        missing = df[col].isna() & ~bad_mask
        if missing.any():
            report.warnings.append(
                f"Column '{col}': missing value(s) in row(s) {_row_numbers(df.index[missing])} - rows removed."
            )
        report.missing_value_rows += int(missing.sum())
        bad_mask |= df[col].isna()

    # --- 4. Out-of-range values --------------------------------------------------
    for col in REQUIRED_COLUMNS:
        lo, hi = RANGES[col]
        oor = df[col].notna() & ((df[col] < lo) | (df[col] > hi))
        if oor.any():
            report.warnings.append(
                f"Column '{col}': value(s) outside {lo}-{hi} in row(s) {_row_numbers(df.index[oor])} - rows removed."
            )
        report.out_of_range_rows += int(oor.sum())
        bad_mask |= oor

    df = df[~bad_mask].reset_index(drop=True)
    report.rows_kept = len(df)

    # --- 5. Is what is left usable? ---------------------------------------------
    if len(df) < MIN_ROWS_FOR_TRAINING:
        raise DatasetValidationError(
            f"Only {len(df)} valid row(s) remain after cleaning; at least {MIN_ROWS_FOR_TRAINING} are needed.",
            report.warnings,
        )
    at_risk = int((df[TARGET_SOURCE] < RISK_THRESHOLD).sum())
    on_track = len(df) - at_risk
    if min(at_risk, on_track) < MIN_CLASS_COUNT:
        raise DatasetValidationError(
            f"The data has {at_risk} student(s) with final marks below {RISK_THRESHOLD:g} and {on_track} at or above it. "
            f"Each group needs at least {MIN_CLASS_COUNT} students to train and test a model.",
            report.warnings,
        )
    return df, report


def load_csv(path_or_buffer):
    """Read a CSV and validate it. Raises DatasetValidationError with friendly messages."""
    try:
        raw = pd.read_csv(path_or_buffer, encoding="utf-8-sig")
    except pd.errors.EmptyDataError:
        raise DatasetValidationError("The file is empty.")
    except (pd.errors.ParserError, UnicodeDecodeError) as exc:
        raise DatasetValidationError(
            "The file could not be read as a CSV. Save it as 'CSV UTF-8' and try again.", [str(exc)[:200]]
        )
    return validate_dataframe(raw)


def load_active_dataset() -> pd.DataFrame:
    """Load the dataset the app is currently using (already validated when saved)."""
    if not ACTIVE_DATASET_PATH.exists():
        raise FileNotFoundError("No active dataset found. Run: python -m ml.data_generator")
    df, _ = load_csv(ACTIVE_DATASET_PATH)
    return df
