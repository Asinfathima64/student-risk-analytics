"""
Dataset service: active-dataset bookkeeping, dashboard summary numbers, upload handling.

Kept separate from the Flask routes so it can be tested without a web server.
"""
import json
import os
import threading
from datetime import datetime, timezone

import pandas as pd

from config import (
    ACTIVE_DATASET_PATH, ACTIVE_DATASET_META_PATH, SAMPLE_DATASET_PATH, MODEL_PATH, METRICS_PATH,
    RANDOM_SEED, RISK_THRESHOLD, TARGET_SOURCE,
)
from ml.data_generator import write_sample_dataset
from ml.data_loader import load_active_dataset, load_csv, DatasetValidationError
from ml.predict import clear_cache, load_pipeline, ModelNotReadyError
from ml.train import train_and_save, train_from_dataframe, save_artifacts

_train_lock = threading.Lock()

SYNTHETIC_LABEL = "Synthetic demonstration data - not real student records"
SCATTER_SAMPLE_SIZE = 300
BIN_EDGES = [0, 40, 50, 60, 70, 80, 90, 100.0001]
BIN_LABELS = ["Below 40", "40-49", "50-59", "60-69", "70-79", "80-89", "90-100"]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def read_active_meta() -> dict:
    if ACTIVE_DATASET_META_PATH.exists():
        return json.loads(ACTIVE_DATASET_META_PATH.read_text(encoding="utf-8"))
    return {"source": SYNTHETIC_LABEL, "is_synthetic": True, "filename": SAMPLE_DATASET_PATH.name,
            "updated_at": None, "validation": None}


def _write_meta(meta: dict) -> None:
    ACTIVE_DATASET_META_PATH.write_text(json.dumps(meta, indent=2), encoding="utf-8")


def _atomic_csv_write(df: pd.DataFrame, path) -> None:
    tmp = str(path) + ".tmp"
    df.to_csv(tmp, index=False)
    os.replace(tmp, path)


def reset_to_sample() -> dict:
    """Regenerate the synthetic sample, make it active, and retrain."""
    with _train_lock:
        df = write_sample_dataset(seed=RANDOM_SEED)
        meta = {"source": SYNTHETIC_LABEL, "is_synthetic": True, "filename": SAMPLE_DATASET_PATH.name,
                "updated_at": _now(), "validation": None}
        _write_meta(meta)
        metrics = train_and_save(df, meta)
        clear_cache()
        return metrics


def retrain_active() -> dict:
    """Retrain on whatever dataset is active right now."""
    with _train_lock:
        df = load_active_dataset()
        metrics = train_and_save(df, read_active_meta())
        clear_cache()
        return metrics


def ingest_upload(file_storage) -> dict:
    """
    Validate an uploaded CSV, train on it, and only then make it the active dataset.
    If anything fails, the previous dataset and model stay untouched.
    """
    filename = file_storage.filename or "upload.csv"
    if not filename.lower().endswith(".csv"):
        raise DatasetValidationError("Please upload a .csv file.")
    df, report = load_csv(file_storage.stream)

    meta = {"source": f"User-uploaded file: {filename}", "is_synthetic": False, "filename": filename,
            "updated_at": _now(), "validation": report.to_dict(), "warnings": report.warnings}
    with _train_lock:
        try:
            pipeline, metrics = train_from_dataframe(df, meta)
        except ValueError as exc:
            raise DatasetValidationError("A model could not be trained on this data.", [str(exc)[:200]])
        _atomic_csv_write(df, ACTIVE_DATASET_PATH)
        _write_meta(meta)
        save_artifacts(pipeline, metrics)
        clear_cache()
    return {"validation": report.to_dict(), "warnings": report.warnings, "dataset": meta}


def ensure_ready() -> None:
    """Called at app start: create the sample dataset and train a model if either is missing/invalid."""
    if not SAMPLE_DATASET_PATH.exists() or not ACTIVE_DATASET_PATH.exists():
        reset_to_sample()
        return
    try:
        load_pipeline()
    except ModelNotReadyError:
        retrain_active()


def dataset_summary() -> dict:
    df = load_active_dataset()
    meta = read_active_meta()
    marks = df[TARGET_SOURCE]
    at_risk_mask = marks < RISK_THRESHOLD

    counts = pd.cut(marks, bins=BIN_EDGES, labels=BIN_LABELS, right=False).value_counts().reindex(BIN_LABELS)
    distribution = [
        {"range": label, "count": int(counts[label]), "below_threshold": bool(BIN_EDGES[i + 1] <= RISK_THRESHOLD)}
        for i, label in enumerate(BIN_LABELS)
    ]

    sample = df.sample(n=min(SCATTER_SAMPLE_SIZE, len(df)), random_state=RANDOM_SEED)

    def points(x_col):
        return [
            {"x": float(r[x_col]), "y": float(r[TARGET_SOURCE]), "at_risk": bool(r[TARGET_SOURCE] < RISK_THRESHOLD)}
            for _, r in sample.iterrows()
        ]

    return {
        "dataset": {
            "label": meta.get("source", SYNTHETIC_LABEL),
            "is_synthetic": meta.get("is_synthetic", True),
            "filename": meta.get("filename"),
            "updated_at": meta.get("updated_at"),
            "validation": meta.get("validation"),
            "warnings": meta.get("warnings", []),
        },
        "risk_threshold": RISK_THRESHOLD,
        "total_students": int(len(df)),
        "average_marks": round(float(marks.mean()), 1),
        "average_attendance": round(float(df["attendance_pct"].mean()), 1),
        "average_study_hours": round(float(df["study_hours_per_day"].mean()), 1),
        "needs_support_count": int(at_risk_mask.sum()),
        "needs_support_pct": round(float(at_risk_mask.mean() * 100), 1),
        "distribution": distribution,
        "attendance_vs_marks": points("attendance_pct"),
        "study_vs_marks": points("study_hours_per_day"),
        "scatter_sample_size": int(len(sample)),
    }
