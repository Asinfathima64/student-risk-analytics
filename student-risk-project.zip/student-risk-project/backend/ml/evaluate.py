"""
Evaluation: turns predictions into metrics. No training happens in this file.

Positive class = 1 = "At Risk". So:
  precision = of the students we flagged, how many really were at risk
  recall    = of the students who really were at risk, how many we caught
"""
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_auc_score,
)

from config import FEATURES, FEATURE_INFO


def compute_metrics(y_true, y_pred, y_proba=None) -> dict:
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    metrics = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "roc_auc": None,
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }
    if y_proba is not None and len(np.unique(y_true)) == 2:
        metrics["roc_auc"] = float(roc_auc_score(y_true, y_proba))
    return metrics


def feature_importance(pipeline) -> list:
    """Normalised importance of each input feature for the fitted pipeline (sums to 1)."""
    model = pipeline.named_steps["model"]
    if hasattr(model, "feature_importances_"):          # Random Forest
        raw = np.asarray(model.feature_importances_, dtype=float)
    elif hasattr(model, "coef_"):                        # Logistic Regression (features are scaled)
        raw = np.abs(np.asarray(model.coef_, dtype=float)).ravel()
    else:
        return []
    total = raw.sum() or 1.0
    items = [
        {"feature": name, "label": FEATURE_INFO[name]["label"], "importance": float(val / total)}
        for name, val in zip(FEATURES, raw)
    ]
    return sorted(items, key=lambda d: d["importance"], reverse=True)
