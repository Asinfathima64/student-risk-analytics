"""
Prediction: safely load the saved pipeline and score one student.

"Safe loading": joblib files can run code when loaded, so we only load OUR OWN model
file, and only after checking its SHA-256 hash against the hash recorded at training time.
"""
import hashlib
import json
import re
import threading

import joblib
import pandas as pd

from config import (
    CLASS_LABELS, FEATURES, FEATURE_INFO, MODEL_PATH, METRICS_PATH, RANGES, RISK_THRESHOLD,
)

_lock = threading.Lock()
_cache = {"pipeline": None, "metrics": None}

SAFETY_NOTICE = (
    "This is a statistical estimate from a demonstration model. It must not be used on its own "
    "to make decisions that affect a student. Combine it with teacher judgement and a conversation with the student."
)


class ModelNotReadyError(RuntimeError):
    pass


class InputValidationError(ValueError):
    def __init__(self, errors: dict):
        super().__init__("Some inputs are invalid.")
        self.errors = errors


def read_metrics() -> dict:
    if not METRICS_PATH.exists():
        raise ModelNotReadyError("No trained model yet. Run: python -m ml.train")
    return json.loads(METRICS_PATH.read_text(encoding="utf-8"))


def load_pipeline(force_reload: bool = False):
    """Load (and cache) the pipeline after verifying its hash."""
    with _lock:
        if _cache["pipeline"] is not None and not force_reload:
            return _cache["pipeline"], _cache["metrics"]
        if not MODEL_PATH.exists():
            raise ModelNotReadyError("No trained model yet. Run: python -m ml.train")
        metrics = read_metrics()
        actual = hashlib.sha256(MODEL_PATH.read_bytes()).hexdigest()
        if actual != metrics.get("model_sha256"):
            raise ModelNotReadyError(
                "The model file does not match its recorded hash (it may be corrupted or changed). "
                "Retrain with: python -m ml.train"
            )
        _cache["pipeline"] = joblib.load(MODEL_PATH)
        _cache["metrics"] = metrics
        return _cache["pipeline"], metrics


def clear_cache():
    with _lock:
        _cache["pipeline"] = None
        _cache["metrics"] = None


def validate_input(payload: dict) -> dict:
    """Return cleaned floats or raise InputValidationError with one message per bad field."""
    if not isinstance(payload, dict):
        raise InputValidationError({"_form": "Send a JSON object with the five input values."})
    errors, clean = {}, {}
    for name in FEATURES:
        label = FEATURE_INFO[name]["label"]
        raw = payload.get(name)
        if raw is None or (isinstance(raw, str) and raw.strip() == ""):
            errors[name] = f"{label} is required."
            continue
        if isinstance(raw, bool):
            errors[name] = f"{label} must be a number."
            continue
        try:
            value = float(raw)
        except (TypeError, ValueError):
            errors[name] = f"{label} must be a number."
            continue
        if value != value or value in (float("inf"), float("-inf")):
            errors[name] = f"{label} must be a finite number."
            continue
        lo, hi = RANGES[name]
        if not lo <= value <= hi:
            errors[name] = f"{label} must be between {lo} and {hi}."
            continue
        clean[name] = value
    if errors:
        raise InputValidationError(errors)
    return clean


def _short(label: str) -> str:
    """'Attendance (%)' -> 'Attendance' (units are noise inside sentences)."""
    return re.sub(r"\s*\(.*?\)", "", label).strip()


def _risk_level(prob: float) -> str:
    if prob < 0.35:
        return "Low"
    if prob < 0.65:
        return "Moderate"
    return "High"


def _build_explanation(values: dict, stats: dict, importance: list, is_at_risk: bool):
    """Compare each input with the training-data average to name factors, strongest first."""
    weight = {d["feature"]: d["importance"] for d in importance} or {f: 1 / len(FEATURES) for f in FEATURES}
    factors = []
    for name in FEATURES:
        mean, std = stats[name]["mean"], stats[name]["std"] or 1.0
        z = (values[name] - mean) / std
        factors.append({
            "feature": name,
            "label": _short(FEATURE_INFO[name]["label"]),
            "value": values[name],
            "dataset_average": round(mean, 1),
            "position": "below average" if z < -0.5 else "above average" if z > 0.5 else "near average",
            "weight": weight.get(name, 0.0),
            "z": z,
        })
    concerns = sorted([f for f in factors if f["position"] == "below average"], key=lambda f: f["z"] * f["weight"])
    strengths = [f for f in factors if f["position"] == "above average"]

    if is_at_risk:
        summary = ("Based on the patterns in the training data, this combination of inputs looks similar to students "
                   "who finished below the pass threshold. That is a signal to offer support early, not a verdict.")
    else:
        summary = ("This combination of inputs looks similar to students who finished at or above the pass threshold. "
                   "Keeping up the current habits should help.")
    if concerns:
        summary += " The areas furthest below average are: " + ", ".join(f["label"] for f in concerns[:2]) + "."
    elif not is_at_risk:
        summary += " No input is notably below the dataset average."

    suggestions = {
        "attendance_pct": "Try to attend more classes and catch up on any sessions that were missed.",
        "study_hours_per_day": "Plan a steady daily study routine; even short, regular sessions help.",
        "previous_marks": "Review the topics from earlier exams that were difficult, and ask about revision resources.",
        "assignment_score": "Review feedback on past assignments and ask the instructor how to improve the next one.",
        "participation_score": "Join class discussions or study groups, and ask questions when something is unclear.",
    }
    tips = [suggestions[f["feature"]] for f in concerns[:3]]
    if is_at_risk:
        tips.append("Consider speaking with the instructor or an academic advisor about available support.")
    elif not tips:
        tips.append("Keep reviewing regularly and talk to the instructor early if any topic feels difficult.")
    return summary, tips, [{k: f[k] for k in ("label", "value", "dataset_average", "position")} for f in factors], \
        [f["label"] for f in strengths]


def predict_one(payload: dict) -> dict:
    values = validate_input(payload)
    pipeline, metrics = load_pipeline()
    frame = pd.DataFrame([values], columns=FEATURES)
    prob_at_risk = float(pipeline.predict_proba(frame)[0, 1])
    is_at_risk = prob_at_risk >= 0.5
    summary, tips, factors, strengths = _build_explanation(
        values, metrics["feature_stats"], metrics.get("feature_importance", []), is_at_risk
    )
    return {
        "category": CLASS_LABELS[1 if is_at_risk else 0],
        "risk_level": _risk_level(prob_at_risk),
        "probability_at_risk": round(prob_at_risk, 4),
        "confidence_in_category": round(prob_at_risk if is_at_risk else 1 - prob_at_risk, 4),
        "probability_note": ("This percentage is the model's estimate, not a certainty. It is only as reliable as the "
                             "data the model was trained on."),
        "explanation": summary,
        "factors": factors,
        "strengths": strengths,
        "suggestions": tips,
        "safety_warning": SAFETY_NOTICE,
        "model": metrics["selected_model"],
        "risk_threshold": RISK_THRESHOLD,
        "dataset_is_synthetic": metrics["dataset"]["is_synthetic"],
    }
