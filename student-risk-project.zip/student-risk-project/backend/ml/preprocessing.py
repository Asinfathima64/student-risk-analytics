"""
Preprocessing: build the feature matrix X, the label y, and the sklearn preprocessing step.

Leakage rule: X contains ONLY the five input features. final_marks is used ONLY to
create the label y, then it is thrown away.
"""
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from config import FEATURES, TARGET_SOURCE, RISK_THRESHOLD


def make_label(final_marks: pd.Series) -> pd.Series:
    """1 = At Risk (final marks below threshold), 0 = On Track."""
    return (final_marks < RISK_THRESHOLD).astype(int)


def split_features_and_label(df: pd.DataFrame):
    X = df[FEATURES].copy()
    y = make_label(df[TARGET_SOURCE])
    assert TARGET_SOURCE not in X.columns, "Target leakage: final_marks must not be a feature"
    return X, y


def build_preprocessor() -> ColumnTransformer:
    """Median-impute (safety net for future missing values) then standardise each feature."""
    numeric_steps = Pipeline(
        steps=[
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]
    )
    return ColumnTransformer([("numeric", numeric_steps, FEATURES)], remainder="drop")
