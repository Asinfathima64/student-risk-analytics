"""
Training: splits data, trains and compares models, saves the best pipeline + metrics.

Run from the backend folder:   python -m ml.train
"""
import hashlib
import json
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import fbeta_score, make_scorer
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline

from config import (
    CV_FOLDS, FEATURES, FEATURE_INFO, MODEL_DIR, MODEL_PATH, METRICS_PATH,
    RANDOM_SEED, RISK_THRESHOLD, TEST_SIZE,
)
from ml.evaluate import compute_metrics, feature_importance
from ml.preprocessing import build_preprocessor, split_features_and_label

HONESTY_WARNING = (
    "Metrics come from a held-out test split of the dataset that was used. If that dataset is "
    "synthetic, high scores only show the model learned the rules used to generate the data - "
    "they do NOT prove it would work on real students."
)


def _candidate_models():
    """Two models to compare. class_weight='balanced' helps with fewer At-Risk students."""
    return {
        "Logistic Regression": LogisticRegression(
            max_iter=1000, class_weight="balanced", random_state=RANDOM_SEED
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, min_samples_leaf=3, class_weight="balanced",
            random_state=RANDOM_SEED, n_jobs=1,
        ),
    }


def _make_pipeline(model) -> Pipeline:
    return Pipeline([("prep", build_preprocessor()), ("model", model)])


def train_from_dataframe(df: pd.DataFrame, dataset_info: dict | None = None):
    """
    Train + evaluate on df. Returns (best_pipeline, metrics_dict). Saves nothing.

    Steps: split (stratified, seeded) -> cross-validate each model on TRAIN only ->
    choose by CV F1 -> report honest metrics on the untouched TEST set.
    """
    X, y = split_features_and_label(df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_SEED, stratify=y
    )

    cv = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_SEED)
    # F2 weights recall twice as much as precision: missing a student who needs help is the costlier mistake.
    f2_scorer = make_scorer(fbeta_score, beta=2, zero_division=0)
    results, fitted = [], {}
    for name, model in _candidate_models().items():
        pipe = _make_pipeline(model)
        cv_f1 = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="f1")
        cv_f2 = cross_val_score(pipe, X_train, y_train, cv=cv, scoring=f2_scorer)
        pipe.fit(X_train, y_train)
        y_pred = pipe.predict(X_test)
        y_proba = pipe.predict_proba(X_test)[:, 1]
        results.append({
            "name": name,
            "cv_f1_mean": float(cv_f1.mean()),
            "cv_f1_std": float(cv_f1.std()),
            "cv_f2_mean": float(cv_f2.mean()),
            "test": compute_metrics(y_test, y_pred, y_proba),
        })
        fitted[name] = pipe

    best = max(results, key=lambda r: r["cv_f2_mean"])
    best_pipe = fitted[best["name"]]

    stats = {
        f: {"mean": float(X_train[f].mean()), "median": float(X_train[f].median()), "std": float(X_train[f].std())}
        for f in FEATURES
    }
    info = dataset_info or {}
    metrics = {
        "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "random_seed": RANDOM_SEED,
        "test_size": TEST_SIZE,
        "cv_folds": CV_FOLDS,
        "risk_threshold": RISK_THRESHOLD,
        "features": FEATURES,
        "dataset": {
            "rows": int(len(df)),
            "at_risk": int(y.sum()),
            "on_track": int((1 - y).sum()),
            "source": info.get("source", "unknown"),
            "is_synthetic": bool(info.get("is_synthetic", False)),
        },
        "split": {
            "train_rows": int(len(X_train)), "test_rows": int(len(X_test)),
            "train_at_risk": int(y_train.sum()), "test_at_risk": int(y_test.sum()),
        },
        "models": results,
        "selected_model": best["name"],
        "selection_rule": f"Highest mean {CV_FOLDS}-fold cross-validated F2 score (recall weighted 2x) on the training split. The test set is not used for selection.",
        "feature_importance": feature_importance(best_pipe),
        "feature_stats": stats,
        "sklearn_version": sklearn.__version__,
        "warning": HONESTY_WARNING,
    }
    return best_pipe, metrics


def save_artifacts(pipeline, metrics: dict) -> None:
    """Save model + metrics. A SHA-256 hash of the model file is stored so loading can verify it."""
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)
    metrics = dict(metrics)
    metrics["model_sha256"] = hashlib.sha256(MODEL_PATH.read_bytes()).hexdigest()
    METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")


def train_and_save(df: pd.DataFrame, dataset_info: dict | None = None) -> dict:
    pipeline, metrics = train_from_dataframe(df, dataset_info)
    save_artifacts(pipeline, metrics)
    return metrics


if __name__ == "__main__":
    from ml.data_loader import load_active_dataset
    data = load_active_dataset()
    result = train_and_save(data, {"source": "Synthetic demonstration dataset", "is_synthetic": True})
    print(f"Trained on {result['dataset']['rows']} rows. Selected: {result['selected_model']}")
    for m in result["models"]:
        t = m["test"]
        print(f"- {m['name']}: acc={t['accuracy']:.3f} prec={t['precision']:.3f} "
              f"recall={t['recall']:.3f} f1={t['f1']:.3f} (CV F2 {m['cv_f2_mean']:.3f})")
    print("Saved:", MODEL_PATH)
