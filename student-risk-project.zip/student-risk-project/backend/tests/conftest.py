"""
Test setup: run every test against a TEMPORARY copy of the data/model folders,
so tests never overwrite your real dataset or trained model.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config  # noqa: E402
from ml import data_generator, data_loader, dataset_service, predict, train  # noqa: E402


@pytest.fixture(scope="session")
def isolated_env(tmp_path_factory):
    root = tmp_path_factory.mktemp("student_risk")
    (root / "data").mkdir()
    (root / "models").mkdir()
    paths = {
        "DATA_DIR": root / "data",
        "MODEL_DIR": root / "models",
        "SAMPLE_DATASET_PATH": root / "data" / "students_synthetic.csv",
        "ACTIVE_DATASET_PATH": root / "data" / "active_dataset.csv",
        "ACTIVE_DATASET_META_PATH": root / "data" / "active_dataset_meta.json",
        "MODEL_PATH": root / "models" / "risk_pipeline.joblib",
        "METRICS_PATH": root / "models" / "metrics.json",
    }
    mp = pytest.MonkeyPatch()
    for module in (config, data_generator, data_loader, dataset_service, predict, train):
        for name, value in paths.items():
            if hasattr(module, name):
                mp.setattr(module, name, value)
    yield paths
    mp.undo()


@pytest.fixture(scope="session")
def ready_env(isolated_env):
    """Isolated folders + synthetic dataset + trained model."""
    dataset_service.reset_to_sample()
    return isolated_env


@pytest.fixture(scope="session")
def client(ready_env):
    from app import create_app
    app = create_app(bootstrap=False)
    app.config["TESTING"] = True
    return app.test_client()


@pytest.fixture()
def clean_df():
    return data_generator.generate_dataset(n_rows=300, seed=7)
