import io

import pandas as pd

GOOD = {"attendance_pct": 90, "study_hours_per_day": 4, "previous_marks": 80,
        "assignment_score": 85, "participation_score": 75}
WEAK = {"attendance_pct": 50, "study_hours_per_day": 0.5, "previous_marks": 35,
        "assignment_score": 40, "participation_score": 20}


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json["status"] == "ok" and r.json["model_ready"] is True


def test_cors_header_for_vite_origin(client):
    r = client.get("/api/health", headers={"Origin": "http://localhost:5173"})
    assert r.headers.get("Access-Control-Allow-Origin") == "http://localhost:5173"


def test_dataset_summary_has_everything_the_dashboard_needs(client):
    r = client.get("/api/dataset/summary")
    assert r.status_code == 200
    d = r.json
    assert d["total_students"] >= 500
    assert d["dataset"]["is_synthetic"] is True
    assert 0 <= d["needs_support_count"] <= d["total_students"]
    assert sum(b["count"] for b in d["distribution"]) == d["total_students"]
    assert len(d["attendance_vs_marks"]) > 0 and len(d["study_vs_marks"]) > 0


def test_model_metrics_endpoint(client):
    r = client.get("/api/model/metrics")
    assert r.status_code == 200
    assert len(r.json["models"]) >= 2
    assert "warning" in r.json


def test_sample_download(client):
    r = client.get("/api/dataset/sample")
    assert r.status_code == 200 and "attachment" in r.headers["Content-Disposition"]
    df = pd.read_csv(io.BytesIO(r.data))
    assert len(df) >= 500 and "final_marks" in df.columns


def test_prediction_returns_all_fields(client):
    r = client.post("/api/predict", json=WEAK)
    assert r.status_code == 200
    for key in ("category", "probability_at_risk", "probability_note", "explanation",
                "suggestions", "safety_warning", "risk_level"):
        assert key in r.json
    assert 0 <= r.json["probability_at_risk"] <= 1


def test_prediction_direction_is_sensible(client):
    weak = client.post("/api/predict", json=WEAK).json
    good = client.post("/api/predict", json=GOOD).json
    assert weak["probability_at_risk"] > good["probability_at_risk"]
    assert weak["category"] == "At Risk" and good["category"] == "On Track"


def test_prediction_rejects_bad_input(client):
    r = client.post("/api/predict", json={**GOOD, "attendance_pct": 150, "study_hours_per_day": "abc"})
    assert r.status_code == 400
    assert "attendance_pct" in r.json["fields"] and "study_hours_per_day" in r.json["fields"]


def test_prediction_rejects_missing_and_non_json(client):
    assert client.post("/api/predict", json={"attendance_pct": 80}).status_code == 400
    assert client.post("/api/predict", data="not json").status_code == 400


def test_upload_rejects_non_csv_and_missing_file(client):
    r = client.post("/api/dataset/upload", data={"file": (io.BytesIO(b"x"), "notes.txt")},
                    content_type="multipart/form-data")
    assert r.status_code == 400 and ".csv" in r.json["error"]
    assert client.post("/api/dataset/upload", data={}, content_type="multipart/form-data").status_code == 400


def test_upload_missing_column_gives_clear_error(client):
    df = pd.read_csv(io.BytesIO(client.get("/api/dataset/sample").data)).drop(columns=["attendance_pct"])
    r = client.post("/api/dataset/upload", data={"file": (io.BytesIO(df.to_csv(index=False).encode()), "a.csv")},
                    content_type="multipart/form-data")
    assert r.status_code == 400 and "attendance_pct" in r.json["error"]


def test_valid_upload_replaces_dataset_then_reset_restores(client):
    df = pd.read_csv(io.BytesIO(client.get("/api/dataset/sample").data)).head(300)
    df.loc[0, "attendance_pct"] = None
    r = client.post("/api/dataset/upload", data={"file": (io.BytesIO(df.to_csv(index=False).encode()), "mine.csv")},
                    content_type="multipart/form-data")
    assert r.status_code == 200
    assert r.json["validation"]["missing_value_rows"] == 1
    summary = client.get("/api/dataset/summary").json
    assert summary["total_students"] == 299 and summary["dataset"]["is_synthetic"] is False
    assert client.post("/api/predict", json=GOOD).status_code == 200      # model still works

    assert client.post("/api/dataset/reset").status_code == 200
    assert client.get("/api/dataset/summary").json["dataset"]["is_synthetic"] is True


def test_unknown_route_is_json(client):
    r = client.get("/api/nope")
    assert r.status_code == 404 and "error" in r.json
