import io

import numpy as np
import pytest

from config import FEATURES, RISK_THRESHOLD
from ml.data_generator import generate_dataset
from ml.data_loader import DatasetValidationError, validate_dataframe, load_csv
from ml.preprocessing import make_label, split_features_and_label


def test_generator_is_reproducible_and_large_enough():
    a, b = generate_dataset(seed=1), generate_dataset(seed=1)
    assert len(a) >= 500
    assert a.equals(b)
    assert not a.equals(generate_dataset(seed=2))


def test_generated_values_are_in_valid_ranges(clean_df):
    for col in FEATURES + ["final_marks"]:
        assert clean_df[col].between(0, 100).all() or col == "study_hours_per_day"
    assert clean_df["study_hours_per_day"].between(0, 16).all()


def test_label_uses_threshold(clean_df):
    y = make_label(clean_df["final_marks"])
    assert ((clean_df["final_marks"] < RISK_THRESHOLD).astype(int) == y).all()


def test_no_target_leakage(clean_df):
    X, y = split_features_and_label(clean_df)
    assert list(X.columns) == FEATURES
    assert "final_marks" not in X.columns


def test_valid_data_passes(clean_df):
    df, report = validate_dataframe(clean_df)
    assert report.rows_kept == len(clean_df)
    assert report.duplicates_removed == 0


def test_duplicates_removed(clean_df):
    import pandas as pd
    dup = pd.concat([clean_df, clean_df.head(5)])
    _, report = validate_dataframe(dup)
    assert report.duplicates_removed == 5


def test_missing_values_removed_with_message(clean_df):
    clean_df.loc[3, "attendance_pct"] = np.nan
    df, report = validate_dataframe(clean_df)
    assert report.missing_value_rows == 1 and len(df) == len(clean_df) - 1
    assert any("attendance_pct" in w and "row" in w for w in report.warnings)


def test_non_numeric_values_removed(clean_df):
    clean_df["assignment_score"] = clean_df["assignment_score"].astype(object)
    clean_df.loc[4, "assignment_score"] = "abc"
    _, report = validate_dataframe(clean_df)
    assert report.non_numeric_rows == 1


def test_out_of_range_removed(clean_df):
    clean_df.loc[2, "final_marks"] = 150
    clean_df.loc[9, "attendance_pct"] = -5
    _, report = validate_dataframe(clean_df)
    assert report.out_of_range_rows == 2


def test_missing_required_column_rejected(clean_df):
    with pytest.raises(DatasetValidationError, match="participation_score"):
        validate_dataframe(clean_df.drop(columns=["participation_score"]))


def test_too_few_rows_rejected(clean_df):
    with pytest.raises(DatasetValidationError, match="at least"):
        validate_dataframe(clean_df.head(20))


def test_single_class_rejected(clean_df):
    clean_df["final_marks"] = 80.0
    with pytest.raises(DatasetValidationError, match="Each group needs"):
        validate_dataframe(clean_df)


def test_unreadable_file_gives_friendly_error():
    with pytest.raises(DatasetValidationError):
        load_csv(io.StringIO(""))
