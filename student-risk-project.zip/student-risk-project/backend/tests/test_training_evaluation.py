import hashlib
import json

import pytest

from config import FEATURES
from ml import predict
from ml.evaluate import compute_metrics
from ml.train import train_from_dataframe, save_artifacts


def test_compute_metrics_known_values():
    y_true = [1, 1, 1, 0, 0, 0, 0, 0]
    y_pred = [1, 1, 0, 0, 0, 0, 1, 0]
    m = compute_metrics(y_true, y_pred)
    assert m["confusion_matrix"] == {"tn": 4, "fp": 1, "fn": 1, "tp": 2}
    assert m["accuracy"] == pytest.approx(6 / 8)
    assert m["precision"] == pytest.approx(2 / 3)
    assert m["recall"] == pytest.approx(2 / 3)
    assert m["f1"] == pytest.approx(2 / 3)


def test_training_compares_two_models_and_reports_valid_metrics(clean_df):
    _, metrics = train_from_dataframe(clean_df, {"source": "test", "is_synthetic": True})
    names = [m["name"] for m in metrics["models"]]
    assert set(names) == {"Logistic Regression", "Random Forest"}
    assert metrics["selected_model"] in names
    for m in metrics["models"]:
        for key in ("accuracy", "precision", "recall", "f1"):
            assert 0.0 <= m["test"][key] <= 1.0
        cm = m["test"]["confusion_matrix"]
        assert sum(cm.values()) == metrics["split"]["test_rows"]
    assert metrics["features"] == FEATURES


def test_split_is_stratified(clean_df):
    _, metrics = train_from_dataframe(clean_df)
    s = metrics["split"]
    overall = metrics["dataset"]["at_risk"] / metrics["dataset"]["rows"]
    test_rate = s["test_at_risk"] / s["test_rows"]
    assert abs(overall - test_rate) < 0.03


def test_training_is_reproducible(clean_df):
    _, a = train_from_dataframe(clean_df)
    _, b = train_from_dataframe(clean_df)
    for ma, mb in zip(a["models"], b["models"]):
        assert ma["test"] == mb["test"]


def test_saved_model_hash_is_verified(ready_env):
    from config import MODEL_PATH
    import ml.predict as p
    p.clear_cache()
    p.load_pipeline(force_reload=True)             # loads fine when untouched
    original = MODEL_PATH.read_bytes()
    try:
        MODEL_PATH.write_bytes(original + b"tampered")
        p.clear_cache()
        with pytest.raises(p.ModelNotReadyError, match="hash"):
            p.load_pipeline(force_reload=True)
    finally:
        MODEL_PATH.write_bytes(original)
        p.clear_cache()


def test_metrics_file_records_hash(ready_env):
    from config import METRICS_PATH, MODEL_PATH
    data = json.loads(METRICS_PATH.read_text())
    assert data["model_sha256"] == hashlib.sha256(MODEL_PATH.read_bytes()).hexdigest()
    assert "synthetic" in data["warning"].lower()
