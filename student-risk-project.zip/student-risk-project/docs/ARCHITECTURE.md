# System Architecture

## Components and data flow

```mermaid
flowchart LR
    subgraph Browser["Browser - React + Vite (localhost:5173)"]
        UI["Pages: Dashboard, Predict, Dataset"]
        API["api/client.js"]
        UI --> API
    end

    subgraph Server["Flask API (127.0.0.1:5000)"]
        ROUTES["app.py - REST endpoints + CORS"]
        SVC["dataset_service.py"]
        LOAD["data_loader.py - validation"]
        PRE["preprocessing.py"]
        TRAIN["train.py"]
        EVAL["evaluate.py"]
        PRED["predict.py"]
        ROUTES --> SVC
        ROUTES --> PRED
        SVC --> LOAD
        SVC --> TRAIN
        TRAIN --> PRE
        TRAIN --> EVAL
    end

    subgraph Files["Local files - no database server"]
        CSV[("data/*.csv")]
        MODEL[("models/risk_pipeline.joblib")]
        METRICS[("models/metrics.json")]
    end

    API -- "HTTP JSON / CSV upload" --> ROUTES
    LOAD --> CSV
    TRAIN --> MODEL
    TRAIN --> METRICS
    PRED --> MODEL
    PRED --> METRICS
```

## Training pipeline

```mermaid
flowchart TD
    A["Load CSV"] --> B["Validate: columns, missing, non-numeric, out-of-range, duplicates"]
    B --> C["Create label: final_marks below 50 means At Risk"]
    C --> D["Keep only 5 input features - drop final_marks"]
    D --> E["Stratified 80/20 train-test split, seed 42"]
    E --> F["5-fold cross-validation on TRAIN: Logistic Regression and Random Forest"]
    F --> G["Select model with best cross-validated F2 score"]
    G --> H["Evaluate on untouched TEST set: accuracy, precision, recall, F1, confusion matrix"]
    H --> I["Save pipeline + metrics.json with SHA-256 hash"]
```

## Prediction flow

```mermaid
sequenceDiagram
    participant U as User
    participant R as React form
    participant F as Flask /api/predict
    participant M as Saved pipeline
    U->>R: Enter 5 values, press Predict
    R->>R: Check ranges in the browser
    R->>F: POST JSON
    F->>F: Validate again on the server
    F->>M: Load (hash verified) and predict_proba
    M-->>F: Probability of At Risk
    F-->>R: Category, probability, explanation, suggestions, warning
    R-->>U: Show result
```

## Design decisions

* **No database:** CSV and one joblib file are enough for a local demo and easier for a beginner to inspect.
* **Validation on both sides:** the browser gives quick feedback; the server is the real gatekeeper.
* **Separate modules:** training (`train.py`) and evaluation (`evaluate.py`) are independent, so metrics logic can be tested on its own.
* **Nothing hardcoded:** dashboard numbers come from `/dataset/summary`, model scores from `metrics.json`, written by training.
