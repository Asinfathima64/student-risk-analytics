# Algorithm and Methodology

## 1. Problem

Given five things known during the course (attendance, study hours, previous marks, assignment score,
participation score), estimate whether a student is likely to finish **below 50 final marks**, so that teachers can
offer support early.

## 2. Target definition

`At Risk = 1` if `final_marks < 50`, otherwise `On Track = 0`. The threshold lives in `backend/config.py` (`RISK_THRESHOLD`).
It is a documented, simple rule, not a universal truth.

## 3. Avoiding target leakage

The label is computed from `final_marks`. If `final_marks` (or anything computed from it, such as a grade letter or
pass/fail flag) were an input, the model would simply read the answer. So the feature list in `config.py` contains
only the five inputs, and `preprocessing.py` asserts that `final_marks` is not in the feature table.

## 4. Steps

1. **Load and validate** the CSV (`data_loader.py`).
2. **Create the label** and the feature table (`preprocessing.py`).
3. **Split** 80% train / 20% test with `random_state=42` and `stratify=y`, so both parts have the same share of at-risk students.
4. **Preprocess inside a Pipeline**: median imputation then standardisation. Fitting these steps inside the pipeline
   means test data never influences them (no leakage from the test set).
5. **Train two models**:
   * **Logistic Regression** - a weighted sum of the inputs turned into a probability. Simple, fast, easy to explain.
   * **Random Forest** - many decision trees voting together. Can capture non-linear patterns.
   * Both use `class_weight="balanced"` because at-risk students are the minority.
6. **Cross-validate** each model on the training part only (5 folds, stratified), scoring **F2**.
7. **Select** the model with the best mean cross-validated F2 (recall counts twice as much as precision).
8. **Evaluate** both models on the test set: accuracy, precision, recall, F1, ROC-AUC, confusion matrix.
9. **Save** the selected pipeline and a `metrics.json` file containing results and a SHA-256 hash of the model file.
10. **Load safely** at prediction time: recompute the hash, refuse to load if it differs.

## 5. Metrics in plain language (positive class = At Risk)

| Metric | Question it answers |
|--------|---------------------|
| Accuracy | Of all students, what share did we classify correctly? (can look good even when the minority class is missed) |
| Precision | Of the students we flagged, what share really were at risk? |
| Recall | Of the students who really were at risk, what share did we find? |
| F1 | A single score balancing precision and recall equally |
| F2 | Like F1 but recall counts twice as much (used to choose the model) |
| Confusion matrix | The four counts: correctly cleared, wrongly flagged, missed, correctly flagged |

**Why recall matters:** a missed at-risk student (false negative) receives no early help. A wrongly flagged student
(false positive) usually only gets a check-in. So missing students is the more costly error.

## 6. Prediction output

* Probability of "At Risk" from `predict_proba`; category is At Risk when it is at least 0.5.
* Risk level wording for readers: Low (< 35%), Moderate (35-65%), High (> 65%).
* The explanation compares each input to the training-set average and mentions the ones that are well below it.
  This is a simple comparison, not a causal explanation.

## 7. Synthetic data generation

`data_generator.py` draws two hidden traits per student (ability and motivation) from normal distributions, builds each
input as a noisy mix of them, and builds `final_marks` as a weighted sum of the inputs plus random noise, clipped to 0-100.
The weights are **assumptions chosen by the author**, not estimated from real students. Same seed gives the same file.
