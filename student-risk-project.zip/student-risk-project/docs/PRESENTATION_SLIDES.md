# Six-Slide Presentation (about 8 minutes + demo)

> Read the live numbers from the dashboard on the day. The figures in this file are from one example run and may differ slightly.

---

## Slide 1 - Title and problem

**AI-Powered Student Performance Prediction and Academic Risk Analysis**
*Your name | Internship project*

* Problem: students who need help are often noticed late.
* Idea: use attendance, study hours and earlier marks to flag who may need support **early**.
* Important: the data is **synthetic demonstration data**, not real students.

*Say:* "I built a full-stack ML application that turns five simple indicators into an early, explainable risk estimate - and I'm being upfront that the data is synthetic."

---

## Slide 2 - Data and target

* 600 synthetic students (seeded generator, reproducible). Columns: attendance, study hours, previous marks, assignment, participation, final marks.
* **Target:** At Risk = final marks below 50 (about 22% of students).
* **No leakage:** final marks is used only to make the label, never as an input.
* CSV upload with validation: missing, non-numeric, out-of-range and duplicate rows are caught and reported.

*Say:* "If the model could see final marks, it would be cheating. So the inputs are only the five early indicators."

---

## Slide 3 - Method

* Pipeline: validate -> label -> stratified 80/20 split (seed 42) -> impute + scale -> train.
* Two models: **Logistic Regression** and **Random Forest**.
* 5-fold cross-validation on training data; model chosen by **F2** (recall counts double).
* Evaluated once on the untouched test set.

*Say:* "Recall matters most: missing a student who needs help is worse than a friendly unnecessary check-in."

---

## Slide 4 - Results (open the Dashboard)

* Table: accuracy, precision, recall, F1 for both models; confusion matrix for the selected one.
* Example run: selected Logistic Regression, recall about 88% (23 of 26 at-risk test students found), 10 unnecessary flags.
* **Honest warning:** high scores on synthetic data show the pipeline works, not that it works on real students.

*Say:* "The generator is mostly linear, so Logistic Regression fits it well. That's a property of my data, not a general conclusion."

---

## Slide 5 - Live demo (Predict page)

1. Click "Example: needs support" -> Predict -> At Risk, probability, supportive explanation, next steps.
2. Click "Example: steady student" -> Predict -> On Track.
3. Type attendance 150 -> show validation message.
4. Dataset page: download sample CSV; upload a CSV with a bad row to show the cleaning report.

*Say:* "Every number you see comes from the Flask API and the saved model - nothing is hardcoded."

---

## Slide 6 - Limitations, ethics, next steps

* Synthetic data; simple threshold; five inputs; small test set; no fairness evaluation.
* Predictions are estimates and **must not be used alone** to make decisions about students.
* Next: real consented data, calibration, fairness checks, explanations (SHAP), authentication and a database.

*Say:* "The most valuable part of this project is the method and the honesty about what it can't show."

---

## Demo checklist (before presenting)

- [ ] Window 1: `python app.py` running, `/api/health` shows ok
- [ ] Window 2: `npm run dev` running, app opens at http://localhost:5173
- [ ] Dataset page -> "Restore sample dataset" (so the dashboard shows the original 600)
- [ ] Have a messy CSV ready for the upload demo
- [ ] Browser zoom at 100%
