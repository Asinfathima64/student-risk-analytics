# Testing

## What was actually run during development

Environment: Linux, Python 3.12.3, Node 22, scikit-learn 1.8.0, pandas 3.0.2, headless Chromium 141.

| Test | How | Result |
|------|-----|--------|
| Backend automated tests (32) | `python -m pytest -q` in `backend` | **32 passed** |
| Frontend API-client integration tests (6) | `npm test` with backend running | **6 passed** |
| Production build | `npm run build` | **Built successfully** |
| Browser walkthrough (19 checks) | One-off headless Chromium script (not shipped) | **19 of 19 passed** |

The browser walkthrough checked that: dashboard KPI values equal the API values; three charts and the model table
render; both example predictions return the expected category; client-side range validation appears; the sample CSV
downloads; a CSV with a missing column shows an error; a messy CSV is accepted with a cleaning report; the dashboard
then shows the uploaded data (197 rows) and hides the synthetic notice; "Restore sample dataset" returns to 600; and at
a 390 px wide window the page does not scroll sideways. The only console error was the expected HTTP 400 from the
deliberately invalid upload.

## What the automated backend tests cover

* Preprocessing: reproducible generator, valid ranges, label threshold, no target leakage, duplicates, missing values, non-numeric values, out-of-range values, missing columns, too few rows, single class, unreadable file.
* Training/evaluation: metric calculation on known values, two models compared, metric ranges, confusion-matrix totals, stratified split, reproducibility, model-hash tamper detection, hash recorded in metrics file, synthetic warning present.
* API: health, CORS header, dataset summary consistency, model metrics, sample download, prediction fields, sensible direction (weak student riskier than strong student), invalid and missing inputs, non-JSON body, non-CSV upload, missing-column upload, valid upload then reset, unknown route returns JSON.

Tests run in a temporary folder and never touch your real dataset or model.

## NOT tested (be honest if asked)

* The Windows PowerShell commands were **not executed on Windows** by the code author. They follow standard Windows practice, but please run through them once before the presentation.
* Browsers other than headless Chromium (Edge, Firefox, Safari) and real phones/tablets. Only a 390 px-wide Chromium window was checked for horizontal overflow.
* Accessibility audit with a screen reader; only basic labels, focus styles and ARIA attributes were added.
* Load, concurrency and security testing. This is a local single-user demo.
* Python versions other than 3.12, and pandas 2.x (the requirements allow it, but only pandas 3.0.2 was used in tests).
* Model quality on any real student data.

## Manual testing checklist (do this before presenting)

**Startup**
- [ ] Backend starts with no errors; <http://127.0.0.1:5000/api/health> shows `"status":"ok"`
- [ ] Frontend opens at <http://localhost:5173> without a red "backend is not responding" banner

**Dashboard**
- [ ] Four KPI cards show numbers (not placeholders)
- [ ] Three charts render with points/bars
- [ ] Model table lists two models; the confusion matrix switches when you click the other model's tab
- [ ] Synthetic-data notice and honest warning are visible

**Predict**
- [ ] "Example: needs support" -> Predict -> shows At Risk, a percentage, explanation, suggestions, warning
- [ ] "Example: steady student" -> Predict -> shows On Track
- [ ] Attendance 150 -> inline error, no request sent
- [ ] Clearing a field -> "Enter a value."
- [ ] Stop the backend, press Predict -> clear "cannot reach the backend" message

**Dataset**
- [ ] "Download sample CSV" saves a file with 600 rows
- [ ] Upload with no file chosen -> "Choose a CSV file first."
- [ ] Upload a `.txt` file -> "Please upload a .csv file."
- [ ] Upload a CSV missing a column -> error naming the column
- [ ] Upload a CSV with some bad rows -> accepted, with a list of removed rows
- [ ] Dashboard now shows the uploaded row count and no synthetic notice
- [ ] "Restore sample dataset" -> back to 600 students
- [ ] "Retrain model" -> success message

**Responsive**
- [ ] Narrow the browser to phone width: no sideways scrolling, tabs still usable
