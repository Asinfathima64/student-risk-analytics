import { useCallback, useEffect, useState } from "react";
import { getHealth } from "./api/client.js";
import Layout from "./components/Layout.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import DatasetPage from "./pages/DatasetPage.jsx";
import Predict from "./pages/Predict.jsx";

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [backendOk, setBackendOk] = useState(null); // null = checking, true/false after the check
  const [dataVersion, setDataVersion] = useState(0); // bump to make pages re-fetch after an upload/reset

  const checkBackend = useCallback(() => {
    getHealth().then((h) => setBackendOk(h.status === "ok" && h.model_ready)).catch(() => setBackendOk(false));
  }, []);

  useEffect(checkBackend, [checkBackend]);

  const recheck = () => {
    checkBackend();
    setDataVersion((v) => v + 1);
  };

  return (
    <Layout page={page} onNavigate={setPage} backendOk={backendOk} onRecheck={recheck}>
      {page === "dashboard" && <Dashboard dataVersion={dataVersion} onNavigate={setPage} />}
      {page === "predict" && <Predict />}
      {page === "dataset" && <DatasetPage dataVersion={dataVersion} onDataChanged={() => setDataVersion((v) => v + 1)} />}
    </Layout>
  );
}
