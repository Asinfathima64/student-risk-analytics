// API client: every request to the Flask backend goes through this file.
// Change the backend address in frontend/.env (VITE_API_URL), not in the code.

export const API_BASE = (import.meta.env?.VITE_API_URL || "http://127.0.0.1:5000/api").replace(/\/$/, "");

export class ApiError extends Error {
  constructor(message, { status = 0, fields = null, details = [] } = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.fields = fields; // per-input messages from /predict
    this.details = details; // extra lines from CSV validation
  }
}

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, options);
  } catch {
    throw new ApiError(
      `Cannot reach the backend at ${API_BASE}. Start it with "python app.py" in the backend folder, then try again.`
    );
  }

  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null; // not JSON (e.g. a proxy error page)
  }

  if (!response.ok) {
    throw new ApiError(body?.error || `The server returned an error (HTTP ${response.status}).`, {
      status: response.status,
      fields: body?.fields || null,
      details: body?.details || [],
    });
  }
  return body;
}

export const getHealth = () => request("/health");
export const getMeta = () => request("/meta");
export const getSummary = () => request("/dataset/summary");
export const getMetrics = () => request("/model/metrics");
export const resetDataset = () => request("/dataset/reset", { method: "POST" });
export const retrainModel = () => request("/model/retrain", { method: "POST" });

export const uploadDataset = (file) => {
  const form = new FormData();
  form.append("file", file);
  return request("/dataset/upload", { method: "POST", body: form });
};

export const predictRisk = (values) =>
  request("/predict", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(values),
  });

export const SAMPLE_CSV_URL = `${API_BASE}/dataset/sample`;
