import {
  Bar, BarChart, CartesianGrid, Cell, Legend, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis,
} from "recharts";

export const COLORS = { onTrack: "#4263eb", atRisk: "#d6336c", grid: "#e6e8f0", axis: "#6b7280", purple: "#7048e8" };

export function DistributionChart({ data, threshold }) {
  return (
    <div className="chart-box">
      <ResponsiveContainer width="100%" height={280}>
        <BarChart data={data} margin={{ top: 8, right: 8, left: -8, bottom: 8 }}>
          <CartesianGrid stroke={COLORS.grid} vertical={false} />
          <XAxis dataKey="range" interval={0} tick={{ fill: COLORS.axis, fontSize: 11 }} />
          <YAxis allowDecimals={false} tick={{ fill: COLORS.axis, fontSize: 12 }} />
          <Tooltip formatter={(v) => [`${v} students`, "Count"]} cursor={{ fill: "#f1f3f9" }} />
          <Bar dataKey="count" radius={[6, 6, 0, 0]}>
            {data.map((d) => (
              <Cell key={d.range} fill={d.below_threshold ? COLORS.atRisk : COLORS.onTrack} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <p className="chart-note">
        <span className="dot" style={{ background: COLORS.atRisk }} /> Final marks below {threshold}
        <span className="dot" style={{ background: COLORS.onTrack, marginLeft: 16 }} /> {threshold} or above
      </p>
    </div>
  );
}

export function MarksScatter({ points, xLabel, xDomain, threshold, sampleSize }) {
  const onTrack = points.filter((p) => !p.at_risk);
  const atRisk = points.filter((p) => p.at_risk);
  return (
    <div className="chart-box">
      <ResponsiveContainer width="100%" height={280}>
        <ScatterChart margin={{ top: 8, right: 12, left: -4, bottom: 18 }}>
          <CartesianGrid stroke={COLORS.grid} />
          <XAxis type="number" dataKey="x" domain={xDomain} name={xLabel} tick={{ fill: COLORS.axis, fontSize: 12 }}
                 label={{ value: xLabel, position: "insideBottom", offset: -10, fill: COLORS.axis, fontSize: 12 }} />
          <YAxis type="number" dataKey="y" domain={[0, 100]} name="Final marks" tick={{ fill: COLORS.axis, fontSize: 12 }}
                 label={{ value: "Final marks", angle: -90, position: "insideLeft", offset: 12, fill: COLORS.axis, fontSize: 12 }} />
          <Tooltip cursor={{ strokeDasharray: "3 3" }} />
          <Legend verticalAlign="top" height={28} wrapperStyle={{ fontSize: 12 }} />
          <Scatter name={`Final marks ${threshold}+`} data={onTrack} fill={COLORS.onTrack} fillOpacity={0.6} />
          <Scatter name={`Final marks below ${threshold}`} data={atRisk} fill={COLORS.atRisk} fillOpacity={0.75} />
        </ScatterChart>
      </ResponsiveContainer>
      <p className="chart-note">Showing a random sample of {sampleSize} students.</p>
    </div>
  );
}
