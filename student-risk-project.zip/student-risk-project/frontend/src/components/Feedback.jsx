// Small shared pieces: spinner, loading block, error block, empty state, notices.

export function Spinner({ label = "Loading" }) {
  return <span className="spinner" role="status" aria-label={label} />;
}

export function LoadingBlock({ text = "Loading data from the backend..." }) {
  return (
    <div className="state-block">
      <Spinner />
      <p>{text}</p>
    </div>
  );
}

export function ErrorBlock({ error, onRetry }) {
  return (
    <div className="state-block state-error" role="alert">
      <p className="state-title">Something went wrong</p>
      <p>{error?.message || "Unknown error."}</p>
      {onRetry && (
        <button className="btn btn-secondary" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}

export function EmptyState({ title, children }) {
  return (
    <div className="state-block">
      <p className="state-title">{title}</p>
      <p>{children}</p>
    </div>
  );
}

export function Notice({ tone = "info", title, children }) {
  return (
    <div className={`notice notice-${tone}`} role={tone === "warning" ? "note" : undefined}>
      {title && <strong>{title} </strong>}
      {children}
    </div>
  );
}
