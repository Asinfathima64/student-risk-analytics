const TABS = [
  { id: "dashboard", label: "Dashboard" },
  { id: "predict", label: "Predict" },
  { id: "dataset", label: "Dataset" },
];

export default function Layout({ page, onNavigate, backendOk, onRecheck, children }) {
  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="topbar-inner">
          <div className="brand">
            <span className="brand-mark" aria-hidden="true">SR</span>
            <div>
              <p className="brand-title">Student Risk Analytics</p>
              <p className="brand-sub">Performance prediction with machine learning</p>
            </div>
          </div>
          <nav className="tabs" aria-label="Main">
            {TABS.map((t) => (
              <button
                key={t.id}
                className={`tab ${page === t.id ? "tab-active" : ""}`}
                aria-current={page === t.id ? "page" : undefined}
                onClick={() => onNavigate(t.id)}
              >
                {t.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {backendOk === false && (
        <div className="backend-banner" role="alert">
          <span>
            The backend is not responding. In a second terminal, run <code>python app.py</code> inside the backend folder.
          </span>
          <button className="btn btn-small" onClick={onRecheck}>Check again</button>
        </div>
      )}

      <main className="page">{children}</main>

      <footer className="footer">
        Educational demonstration project. Predictions are estimates and must not be used alone to make decisions about students.
      </footer>
    </div>
  );
}
