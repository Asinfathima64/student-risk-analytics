import { useState } from "react";
import { Notice } from "./Feedback.jsx";

const pct = (v) => (v == null ? "n/a" : `${(v * 100).toFixed(1)}%`);

function ConfusionMatrix({ cm }) {
  return (
    <div className="cm" role="table" aria-label="Confusion matrix">
      <div className="cm-corner" />
      <div className="cm-head">Predicted On Track</div>
      <div className="cm-head">Predicted At Risk</div>
      <div className="cm-side">Actually On Track</div>
      <div className="cm-cell cm-good"><strong>{cm.tn}</strong><span>correctly cleared</span></div>
      <div className="cm-cell cm-warn"><strong>{cm.fp}</strong><span>flagged unnecessarily</span></div>
      <div className="cm-side">Actually At Risk</div>
      <div className="cm-cell cm-bad"><strong>{cm.fn}</strong><span>missed</span></div>
      <div className="cm-cell cm-good"><strong>{cm.tp}</strong><span>correctly flagged</span></div>
    </div>
  );
}

export default function ModelEvaluation({ metrics }) {
  const [shown, setShown] = useState(metrics.selected_model);
  const model = metrics.models.find((m) => m.name === shown) || metrics.models[0];
  const t = model.test;
  const maxImportance = Math.max(...metrics.feature_importance.map((f) => f.importance), 0.0001);

  return (
    <div className="eval">
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th>Model</th><th>Accuracy</th><th>Precision</th><th>Recall</th><th>F1-score</th><th>CV F2 (train)</th>
            </tr>
          </thead>
          <tbody>
            {metrics.models.map((m) => (
              <tr key={m.name} className={m.name === metrics.selected_model ? "row-selected" : ""}>
                <td>
                  {m.name} {m.name === metrics.selected_model && <span className="tag">Selected</span>}
                </td>
                <td>{pct(m.test.accuracy)}</td>
                <td>{pct(m.test.precision)}</td>
                <td><strong>{pct(m.test.recall)}</strong></td>
                <td>{pct(m.test.f1)}</td>
                <td>{pct(m.cv_f2_mean)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="muted small">
        Selection rule: {metrics.selection_rule} Scores are on a held-out test set of {metrics.split.test_rows} students
        ({metrics.split.test_at_risk} at risk), random seed {metrics.random_seed}.
      </p>

      <div className="eval-grid">
        <div>
          <div className="segmented" role="tablist" aria-label="Choose model for confusion matrix">
            {metrics.models.map((m) => (
              <button key={m.name} role="tab" aria-selected={m.name === shown}
                      className={`seg ${m.name === shown ? "seg-active" : ""}`} onClick={() => setShown(m.name)}>
                {m.name}
              </button>
            ))}
          </div>
          <ConfusionMatrix cm={t.confusion_matrix} />
          <p className="muted small">
            Recall {pct(t.recall)} means the model caught {t.confusion_matrix.tp} of the{" "}
            {t.confusion_matrix.tp + t.confusion_matrix.fn} students who were truly at risk.
          </p>
        </div>

        <div>
          <h3 className="h3">Which inputs matter most ({metrics.selected_model})</h3>
          <ul className="bars">
            {metrics.feature_importance.map((f) => (
              <li key={f.feature}>
                <span className="bar-label">{f.label.replace(/\s*\(.*?\)/g, "")}</span>
                <span className="bar-track"><span className="bar-fill" style={{ width: `${(f.importance / maxImportance) * 100}%` }} /></span>
                <span className="bar-value">{pct(f.importance)}</span>
              </li>
            ))}
          </ul>
          <p className="muted small">Importance shows what the model relies on. It does not prove cause and effect.</p>
        </div>
      </div>

      <div className="why-recall">
        <h3 className="h3">Why recall matters here</h3>
        <p>
          Recall is the share of truly at-risk students the model finds. A missed student (a false negative) gets no
          early support, which is the costly mistake. A student flagged unnecessarily (a false positive) usually only
          receives a friendly check-in. So recall is watched closely, while precision shows how many flags are
          unnecessary.
        </p>
      </div>

      <Notice tone="warning" title="Honest warning.">{metrics.warning}</Notice>
    </div>
  );
}
