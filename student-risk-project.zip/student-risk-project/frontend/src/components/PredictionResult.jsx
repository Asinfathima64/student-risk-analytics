import { Notice } from "./Feedback.jsx";

export default function PredictionResult({ result }) {
  const atRisk = result.category === "At Risk";
  const pct = Math.round(result.probability_at_risk * 1000) / 10;

  return (
    <div className="result" aria-live="polite">
      <div className="result-top">
        <span className={`badge ${atRisk ? "badge-risk" : "badge-ok"}`}>{result.category}</span>
        <span className="muted small">Risk level: {result.risk_level} | Model: {result.model}</span>
      </div>

      <div className="meter" aria-label={`Estimated probability of being at risk: ${pct} percent`}>
        <div className="meter-track">
          <div className="meter-fill" style={{ width: `${pct}%` }} />
          <div className="meter-mark" style={{ left: "50%" }} title="Decision point (50%)" />
        </div>
        <p>
          Estimated chance of finishing below {result.risk_threshold} marks: <strong>{pct}%</strong>
        </p>
      </div>
      <p className="muted small">{result.probability_note}</p>

      <h3 className="h3">What the model noticed</h3>
      <p>{result.explanation}</p>
      <div className="table-wrap">
        <table className="table table-compact">
          <thead><tr><th>Input</th><th>This student</th><th>Dataset average</th><th>Versus average</th></tr></thead>
          <tbody>
            {result.factors.map((f) => (
              <tr key={f.label}>
                <td>{f.label}</td><td>{f.value}</td><td>{f.dataset_average}</td>
                <td><span className={`pos pos-${f.position.split(" ")[0]}`}>{f.position}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h3 className="h3">Suggested next steps</h3>
      <ul className="list">
        {result.suggestions.map((s) => <li key={s}>{s}</li>)}
      </ul>

      {result.dataset_is_synthetic && (
        <Notice tone="info">This model was trained on synthetic demonstration data.</Notice>
      )}
      <Notice tone="warning" title="Please read.">{result.safety_warning}</Notice>
    </div>
  );
}
