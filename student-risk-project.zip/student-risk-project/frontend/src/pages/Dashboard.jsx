import { getMetrics, getSummary } from "../api/client.js";
import { useApi } from "../api/useApi.js";
import { DistributionChart, MarksScatter } from "../components/Charts.jsx";
import { EmptyState, ErrorBlock, LoadingBlock, Notice } from "../components/Feedback.jsx";
import ModelEvaluation from "../components/ModelEvaluation.jsx";
import StatCard from "../components/StatCard.jsx";

function Section({ title, subtitle, children }) {
  return (
    <section className="card">
      <div className="card-head">
        <h2 className="h2">{title}</h2>
        {subtitle && <p className="muted small">{subtitle}</p>}
      </div>
      {children}
    </section>
  );
}

export default function Dashboard({ dataVersion, onNavigate }) {
  const summary = useApi(getSummary, [dataVersion]);
  const metrics = useApi(getMetrics, [dataVersion]);

  if (summary.loading && !summary.data) return <LoadingBlock text="Loading the dashboard..." />;
  if (summary.error) return <ErrorBlock error={summary.error} onRetry={summary.reload} />;

  const s = summary.data;
  if (!s || s.total_students === 0) {
    return <EmptyState title="No student records yet">Upload a CSV on the Dataset page to get started.</EmptyState>;
  }

  return (
    <div className="stack">
      <div className="page-head">
        <h1 className="h1">Class performance overview</h1>
        <p className="muted">{s.dataset.label}</p>
      </div>

      {s.dataset.is_synthetic && (
        <Notice tone="warning" title="Demonstration data.">
          These records are synthetic (computer-generated). They are not real students, and results here cannot be
          treated as real findings.
        </Notice>
      )}

      <div className="grid-4">
        <StatCard label="Total students" value={s.total_students.toLocaleString()} tone="blue" />
        <StatCard label="Average final marks" value={s.average_marks} hint="out of 100" tone="purple" />
        <StatCard label="Average attendance" value={`${s.average_attendance}%`} tone="blue" />
        <StatCard
          label="May need academic support"
          value={s.needs_support_count}
          hint={`${s.needs_support_pct}% scored below ${s.risk_threshold} in final marks`}
          tone="rose"
        />
      </div>

      <div className="grid-3">
        <Section title="Distribution of final marks" subtitle="How many students fall in each mark band">
          <DistributionChart data={s.distribution} threshold={s.risk_threshold} />
        </Section>
        <Section title="Attendance and marks" subtitle="Each dot is one student">
          <MarksScatter points={s.attendance_vs_marks} xLabel="Attendance (%)" xDomain={[30, 100]}
                        threshold={s.risk_threshold} sampleSize={s.scatter_sample_size} />
        </Section>
        <Section title="Study hours and marks" subtitle="Each dot is one student">
          <MarksScatter points={s.study_vs_marks} xLabel="Study hours per day" xDomain={[0, "auto"]}
                        threshold={s.risk_threshold} sampleSize={s.scatter_sample_size} />
        </Section>
      </div>

      <Section title="Model evaluation" subtitle="How well the trained models perform on held-out test data">
        {metrics.loading && !metrics.data ? (
          <LoadingBlock text="Loading model results..." />
        ) : metrics.error ? (
          <ErrorBlock error={metrics.error} onRetry={metrics.reload} />
        ) : (
          <ModelEvaluation key={metrics.data.trained_at} metrics={metrics.data} />
        )}
      </Section>

      <div className="cta-row">
        <button className="btn btn-primary" onClick={() => onNavigate("predict")}>Try a live prediction</button>
        <button className="btn btn-secondary" onClick={() => onNavigate("dataset")}>Manage dataset</button>
      </div>
    </div>
  );
}
