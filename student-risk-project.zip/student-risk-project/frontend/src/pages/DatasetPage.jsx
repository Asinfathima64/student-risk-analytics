import { useRef, useState } from "react";
import { getMeta, getSummary, resetDataset, retrainModel, SAMPLE_CSV_URL, uploadDataset } from "../api/client.js";
import { useApi } from "../api/useApi.js";
import { ErrorBlock, LoadingBlock, Notice, Spinner } from "../components/Feedback.jsx";

const COLUMN_HELP = [
  ["attendance_pct", "0 to 100"],
  ["study_hours_per_day", "0 to 16"],
  ["previous_marks", "0 to 100"],
  ["assignment_score", "0 to 100"],
  ["participation_score", "0 to 100"],
  ["final_marks", "0 to 100 (used only to create the risk label)"],
  ["student_id", "optional text"],
];

export default function DatasetPage({ dataVersion, onDataChanged }) {
  const summary = useApi(getSummary, [dataVersion]);
  const meta = useApi(getMeta, []);
  const fileInput = useRef(null);
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(null); // "upload" | "reset" | "retrain" | null
  const [outcome, setOutcome] = useState(null); // { tone, message, lines }

  const run = async (kind, action, successText) => {
    setBusy(kind);
    setOutcome(null);
    try {
      const res = await action();
      setOutcome({ tone: "success", message: successText(res), lines: res?.warnings || [], report: res?.validation });
      onDataChanged();
    } catch (err) {
      setOutcome({ tone: "error", message: err.message, lines: err.details || [] });
    } finally {
      setBusy(null);
    }
  };

  const onUpload = () => {
    if (!file) {
      setOutcome({ tone: "error", message: "Choose a CSV file first.", lines: [] });
      return;
    }
    run("upload", () => uploadDataset(file), () => `"${file.name}" was accepted and the model was retrained.`).then(() => {
      setFile(null);
      if (fileInput.current) fileInput.current.value = "";
    });
  };

  const d = summary.data?.dataset;

  return (
    <div className="stack">
      <div className="page-head">
        <h1 className="h1">Dataset management</h1>
        <p className="muted">Download the sample, upload your own CSV, or restore the original demonstration data.</p>
      </div>

      <div className="grid-2">
        <section className="card">
          <div className="card-head"><h2 className="h2">Current dataset</h2></div>
          {summary.loading && !summary.data ? <LoadingBlock /> : summary.error ? (
            <ErrorBlock error={summary.error} onRetry={summary.reload} />
          ) : (
            <>
              <p><strong>{d.label}</strong></p>
              <p className="muted">{summary.data.total_students} students after cleaning</p>
              {d.is_synthetic && <Notice tone="warning">Synthetic demonstration data - not real student records.</Notice>}
              {d.validation && (
                <ul className="list small">
                  <li>Rows received: {d.validation.rows_received}, kept: {d.validation.rows_kept}</li>
                  <li>Duplicates removed: {d.validation.duplicates_removed}</li>
                  <li>Missing-value rows removed: {d.validation.missing_value_rows}</li>
                  <li>Non-numeric rows removed: {d.validation.non_numeric_rows}</li>
                  <li>Out-of-range rows removed: {d.validation.out_of_range_rows}</li>
                </ul>
              )}
            </>
          )}
          <div className="btn-row">
            <a className="btn btn-secondary" href={SAMPLE_CSV_URL} download>Download sample CSV</a>
            <button className="btn btn-secondary" disabled={busy !== null}
                    onClick={() => run("reset", resetDataset, () => "The sample dataset was restored and the model retrained.")}>
              {busy === "reset" ? <><Spinner /> Restoring...</> : "Restore sample dataset"}
            </button>
            <button className="btn btn-secondary" disabled={busy !== null}
                    onClick={() => run("retrain", retrainModel, (r) => `Model retrained. Selected model: ${r.selected_model}.`)}>
              {busy === "retrain" ? <><Spinner /> Retraining...</> : "Retrain model"}
            </button>
          </div>
        </section>

        <section className="card">
          <div className="card-head"><h2 className="h2">Upload a CSV</h2></div>
          <p className="muted small">
            Maximum {meta.data?.max_upload_mb ?? 5} MB. Rows with missing, non-numeric, out-of-range or duplicate values
            are removed and reported. The model is retrained on the cleaned data; if the file is unusable, nothing changes.
          </p>
          <div className="upload">
            <input ref={fileInput} id="csv" type="file" accept=".csv,text/csv"
                   onChange={(e) => { setFile(e.target.files?.[0] || null); setOutcome(null); }} />
            <button className="btn btn-primary" onClick={onUpload} disabled={busy !== null}>
              {busy === "upload" ? <><Spinner /> Validating and training...</> : "Upload and validate"}
            </button>
          </div>

          {outcome && (
            <div className={`outcome outcome-${outcome.tone}`} role={outcome.tone === "error" ? "alert" : "status"}>
              <p><strong>{outcome.tone === "error" ? "Upload not accepted: " : ""}</strong>{outcome.message}</p>
              {outcome.lines.length > 0 && <ul className="list small">{outcome.lines.map((l, i) => <li key={i}>{l}</li>)}</ul>}
            </div>
          )}

          <h3 className="h3">Required columns</h3>
          <div className="table-wrap">
            <table className="table table-compact">
              <thead><tr><th>Column</th><th>Valid values</th></tr></thead>
              <tbody>{COLUMN_HELP.map(([c, v]) => <tr key={c}><td><code>{c}</code></td><td>{v}</td></tr>)}</tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}
