import { useState } from "react";
import { getMeta, predictRisk } from "../api/client.js";
import { useApi } from "../api/useApi.js";
import { ErrorBlock, LoadingBlock, Spinner } from "../components/Feedback.jsx";
import PredictionResult from "../components/PredictionResult.jsx";

const EXAMPLES = {
  "Example: steady student": { attendance_pct: 92, study_hours_per_day: 4, previous_marks: 78, assignment_score: 84, participation_score: 72 },
  "Example: needs support": { attendance_pct: 58, study_hours_per_day: 1, previous_marks: 42, assignment_score: 45, participation_score: 30 },
};

function validate(features, values) {
  const errors = {};
  for (const f of features) {
    const raw = values[f.name];
    if (raw === "" || raw === undefined) errors[f.name] = "Enter a value.";
    else if (Number.isNaN(Number(raw))) errors[f.name] = "Enter a number.";
    else if (Number(raw) < f.min || Number(raw) > f.max) errors[f.name] = `Must be between ${f.min} and ${f.max}.`;
  }
  return errors;
}

export default function Predict() {
  const meta = useApi(getMeta, []);
  const [values, setValues] = useState(null);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [apiError, setApiError] = useState(null);

  if (meta.loading) return <LoadingBlock text="Loading the form..." />;
  if (meta.error) return <ErrorBlock error={meta.error} onRetry={meta.reload} />;

  const features = meta.data.features;
  const current = values || Object.fromEntries(features.map((f) => [f.name, f.default]));

  const setField = (name, v) => {
    setValues({ ...current, [name]: v });
    setErrors((e) => ({ ...e, [name]: undefined }));
  };

  const submit = async (event) => {
    event.preventDefault();
    setApiError(null);
    const found = validate(features, current);
    setErrors(found);
    if (Object.keys(found).length) return;

    setSubmitting(true);
    try {
      const payload = Object.fromEntries(features.map((f) => [f.name, Number(current[f.name])]));
      setResult(await predictRisk(payload));
    } catch (err) {
      setResult(null);
      if (err.fields) setErrors(err.fields);
      setApiError(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="stack">
      <div className="page-head">
        <h1 className="h1">Live prediction</h1>
        <p className="muted">Enter a student's current figures to see the model's estimate. Every result comes from the backend model.</p>
      </div>

      <div className="grid-2">
        <section className="card">
          <div className="card-head"><h2 className="h2">Student details</h2></div>
          <div className="chip-row">
            {Object.entries(EXAMPLES).map(([label, ex]) => (
              <button key={label} type="button" className="chip" onClick={() => { setValues(ex); setErrors({}); }}>
                {label}
              </button>
            ))}
          </div>

          <form onSubmit={submit} noValidate className="form">
            {features.map((f) => (
              <div key={f.name} className="field">
                <label htmlFor={f.name}>{f.label}</label>
                <input
                  id={f.name} type="number" inputMode="decimal" min={f.min} max={f.max} step={f.step}
                  value={current[f.name]} onChange={(e) => setField(f.name, e.target.value)}
                  aria-invalid={Boolean(errors[f.name])} aria-describedby={`${f.name}-msg`}
                />
                <p id={`${f.name}-msg`} className={errors[f.name] ? "field-error" : "field-hint"}>
                  {errors[f.name] || `Between ${f.min} and ${f.max}`}
                </p>
              </div>
            ))}
            <button className="btn btn-primary btn-block" type="submit" disabled={submitting}>
              {submitting ? <><Spinner label="Predicting" /> Predicting...</> : "Predict academic risk"}
            </button>
          </form>
          {apiError && !apiError.fields && <ErrorBlock error={apiError} />}
        </section>

        <section className="card">
          <div className="card-head"><h2 className="h2">Result</h2></div>
          {result ? (
            <PredictionResult result={result} />
          ) : (
            <div className="state-block">
              <p className="state-title">No prediction yet</p>
              <p>Fill in the form and choose "Predict academic risk". Your result will appear here.</p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
