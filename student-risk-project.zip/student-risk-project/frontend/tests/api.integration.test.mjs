// Integration test for the frontend API client against a RUNNING backend.
// Start the backend first (python app.py), then run:  npm test
// If the backend is not running, these tests are skipped (not passed).
import test from "node:test";
import assert from "node:assert/strict";
import { getHealth, getSummary, getMetrics, predictRisk, uploadDataset, ApiError, API_BASE } from "../src/api/client.js";

let backendUp = false;
try {
  backendUp = (await getHealth()).status === "ok";
} catch {
  backendUp = false;
}
const opts = { skip: backendUp ? false : `backend not reachable at ${API_BASE}` };

test("health endpoint", opts, async () => {
  const h = await getHealth();
  assert.equal(h.model_ready, true);
});

test("dataset summary feeds the dashboard", opts, async () => {
  const s = await getSummary();
  assert.ok(s.total_students > 0);
  assert.ok(s.distribution.length > 0);
  assert.ok(s.attendance_vs_marks.length > 0);
});

test("model metrics include two models and the honesty warning", opts, async () => {
  const m = await getMetrics();
  assert.ok(m.models.length >= 2);
  assert.match(m.warning, /synthetic/i);
});

test("prediction returns a category and a probability between 0 and 1", opts, async () => {
  const r = await predictRisk({ attendance_pct: 60, study_hours_per_day: 1, previous_marks: 45, assignment_score: 50, participation_score: 30 });
  assert.ok(["At Risk", "On Track"].includes(r.category));
  assert.ok(r.probability_at_risk >= 0 && r.probability_at_risk <= 1);
});

test("invalid prediction input raises ApiError with field messages", opts, async () => {
  await assert.rejects(predictRisk({ attendance_pct: 500 }), (err) => err instanceof ApiError && Boolean(err.fields?.attendance_pct));
});

test("non-CSV upload is rejected with a clear message", opts, async () => {
  const file = new File(["hello"], "notes.txt", { type: "text/plain" });
  await assert.rejects(uploadDataset(file), (err) => err instanceof ApiError && /\.csv/.test(err.message));
});
